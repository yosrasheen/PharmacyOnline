﻿using System.Web.UI;
using System.Web;
using System;
using System.Web.UI.WebControls;
using System.Text;
/// <summary>
/// Summary description for Helper
/// </summary>
public class Helper
{
	public Helper()
	{
		//
		// TODO: Add constructor logic here
        
		//
	}
    public static void alert(Page p,string key, string msg)
    {
        ScriptManager.RegisterStartupScript(p, p.GetType(),key, "alert('" + msg + "')", true);
        //  ClientScriptManager csm = p.ClientScript; if (!csm.IsClientScriptBlockRegistered(ddl.GetType(), "PopupScript")) { csm.RegisterStartupScript(ddl.GetType(), "PopupScript", "alert('" + msg + "');", true); } 
    }
    //public object getLastSearch()
    //{
    //    if (HttpContext.Current.Session["LstSearch"] != null)
    //        return HttpContext.Current.Session["LstSearch"];
    //    return null;
    //}
    public static string FormatPrice(object vPrice)
    {
        return Convert.ToDecimal(vPrice).ToString("N2") + " $";
    }
    public static void CreateCountries(DropDownList ddl)
    {
        ddl.Items.Clear();
        ddl.Items.Add(new ListItem("Choose a Country", "0"));
        ddl.Items.Add(new ListItem("United States", "US"));
        ddl.Items.Add(new ListItem("Canada", "CA"));
        ddl.Items.Add(new ListItem("Afghanistan", "AF"));
        ddl.Items.Add(new ListItem("Albania", "AL"));
        ddl.Items.Add(new ListItem("Algeria", "DZ"));
        ddl.Items.Add(new ListItem("American Samoa", "AS"));
        ddl.Items.Add(new ListItem("Andorra", "AD"));
        ddl.Items.Add(new ListItem("Angola", "AO"));
        ddl.Items.Add(new ListItem("Anguilla", "AI"));
        ddl.Items.Add(new ListItem("Antarctica", "AQ"));
        ddl.Items.Add(new ListItem("Antigua and Barbuda", "AG"));
        ddl.Items.Add(new ListItem("Argentina", "AR"));
        ddl.Items.Add(new ListItem("Armenia", "AM"));
        ddl.Items.Add(new ListItem("Aruba", "AW"));
        ddl.Items.Add(new ListItem("Australia", "AU"));
        ddl.Items.Add(new ListItem("Austria", "AT"));
        ddl.Items.Add(new ListItem("Azerbaijan", "AZ"));
        ddl.Items.Add(new ListItem("Bahamas", "BS"));
        ddl.Items.Add(new ListItem("Bahrain", "BH"));
        ddl.Items.Add(new ListItem("Bangladesh", "BD"));
        ddl.Items.Add(new ListItem("Barbados", "BB"));
        ddl.Items.Add(new ListItem("Belarus", "BY"));
        ddl.Items.Add(new ListItem("Belgium", "BE"));
        ddl.Items.Add(new ListItem("Belize", "BZ"));
        ddl.Items.Add(new ListItem("Benin", "BJ"));
        ddl.Items.Add(new ListItem("Bermuda", "BM"));
        ddl.Items.Add(new ListItem("Bhutan", "BT"));
        ddl.Items.Add(new ListItem("Bolivia", "BO"));
        ddl.Items.Add(new ListItem("Bosnia and Herzegovina", "BA"));
        ddl.Items.Add(new ListItem("Botswana", "BW"));
        ddl.Items.Add(new ListItem("Bouvet Island", "BV"));
        ddl.Items.Add(new ListItem("Brazil", "BR"));
        ddl.Items.Add(new ListItem("British Indian Ocean Territory", "IO"));
        ddl.Items.Add(new ListItem("Brunei Darussalam", "BN"));
        ddl.Items.Add(new ListItem("Bulgaria", "BG"));
        ddl.Items.Add(new ListItem("Burkina Faso", "BF"));
        ddl.Items.Add(new ListItem("Burundi", "BI"));
        ddl.Items.Add(new ListItem("Cambodia", "KH"));
        ddl.Items.Add(new ListItem("Cameroon", "CM"));
        ddl.Items.Add(new ListItem("Cape Verde", "CV"));
        ddl.Items.Add(new ListItem("Cayman Islands", "KY"));
        ddl.Items.Add(new ListItem("Central African Republic", "CF"));
        ddl.Items.Add(new ListItem("Chad", "TD"));
        ddl.Items.Add(new ListItem("Chile", "CL"));
        ddl.Items.Add(new ListItem("China", "CN"));
        ddl.Items.Add(new ListItem("Christmas Island", "CX"));
        ddl.Items.Add(new ListItem("Cocos (Keeling) Islands", "CC"));
        ddl.Items.Add(new ListItem("Colombia", "CO"));
        ddl.Items.Add(new ListItem("Comoros", "KM"));
        ddl.Items.Add(new ListItem("Congo", "CG"));
        ddl.Items.Add(new ListItem("Cook Islands", "CK"));
        ddl.Items.Add(new ListItem("Costa Rica", "CR"));
        ddl.Items.Add(new ListItem("Cote D'Ivoire (Ivory Coast)", "CI"));
        ddl.Items.Add(new ListItem("Croatia (Hrvatska)", "HR"));
        ddl.Items.Add(new ListItem("Cuba", "CU"));
        ddl.Items.Add(new ListItem("Cyprus", "CY"));
        ddl.Items.Add(new ListItem("Czech Republic", "CZ"));
        ddl.Items.Add(new ListItem("Denmark", "DK"));
        ddl.Items.Add(new ListItem("Djibouti", "DJ"));
        ddl.Items.Add(new ListItem("Dominica", "DM"));
        ddl.Items.Add(new ListItem("Dominican Republic", "DO"));
        ddl.Items.Add(new ListItem("East Timor", "TP"));
        ddl.Items.Add(new ListItem("Ecuador", "EC"));
        ddl.Items.Add(new ListItem("Egypt", "EG"));
        ddl.Items.Add(new ListItem("El Salvador", "SV"));
        ddl.Items.Add(new ListItem("Equatorial Guinea", "GQ"));
        ddl.Items.Add(new ListItem("Eritrea", "ER"));
        ddl.Items.Add(new ListItem("Estonia", "EE"));
        ddl.Items.Add(new ListItem("Ethiopia", "ET"));
        ddl.Items.Add(new ListItem("Falkland Islands (Malvinas)", "FK"));
        ddl.Items.Add(new ListItem("Faroe Islands", "FO"));
        ddl.Items.Add(new ListItem("Fiji", "FJ"));
        ddl.Items.Add(new ListItem("Finland", "FI"));
        ddl.Items.Add(new ListItem("France", "FR"));
        ddl.Items.Add(new ListItem("French Guiana", "GF"));
        ddl.Items.Add(new ListItem("French Polynesia", "PF"));
        ddl.Items.Add(new ListItem("French Southern Territories", "TF"));
        ddl.Items.Add(new ListItem("Gabon", "GA"));
        ddl.Items.Add(new ListItem("Gambia", "GM"));
        ddl.Items.Add(new ListItem("Gaza", "GZ"));
        ddl.Items.Add(new ListItem("Georgia", "GE"));
        ddl.Items.Add(new ListItem("Germany", "DE"));
        ddl.Items.Add(new ListItem("Ghana", "GH"));
        ddl.Items.Add(new ListItem("Gibraltar", "GI"));
        ddl.Items.Add(new ListItem("Greece", "GR"));
        ddl.Items.Add(new ListItem("Greenland", "GL"));
        ddl.Items.Add(new ListItem("Grenada", "GD"));
        ddl.Items.Add(new ListItem("Guadeloupe", "GP"));
        ddl.Items.Add(new ListItem("Guam", "GU"));
        ddl.Items.Add(new ListItem("Guatemala", "GT"));
        ddl.Items.Add(new ListItem("Guinea", "GN"));
        ddl.Items.Add(new ListItem("Guinea-Bissau", "GW"));
        ddl.Items.Add(new ListItem("Guyana", "GY"));
        ddl.Items.Add(new ListItem("Haiti", "HT"));
        ddl.Items.Add(new ListItem("Heard and McDonald Islands", "HM"));
        ddl.Items.Add(new ListItem("Honduras", "HN"));
        ddl.Items.Add(new ListItem("Hong Kong", "HK"));
        ddl.Items.Add(new ListItem("Hungary", "HU"));
        ddl.Items.Add(new ListItem("Iceland", "IS"));
        ddl.Items.Add(new ListItem("India", "IN"));
        ddl.Items.Add(new ListItem("Indonesia", "ID"));
        ddl.Items.Add(new ListItem("Iran", "IR"));
        ddl.Items.Add(new ListItem("Iraq", "IQ"));
        ddl.Items.Add(new ListItem("Ireland", "IE"));
        //ddl.Items.Add(new ListItem("Israel", "IL"));
        ddl.Items.Add(new ListItem("Italy", "IT"));
        ddl.Items.Add(new ListItem("Jamaica", "JM"));
        ddl.Items.Add(new ListItem("Japan", "JP"));
        ddl.Items.Add(new ListItem("Jordan", "JO"));
        ddl.Items.Add(new ListItem("Kazakhstan", "KZ"));
        ddl.Items.Add(new ListItem("Kenya", "KE"));
        ddl.Items.Add(new ListItem("Kiribati", "KI"));
        ddl.Items.Add(new ListItem("Korea (North)", "KP"));
        ddl.Items.Add(new ListItem("Korea (South)", "KR"));
        ddl.Items.Add(new ListItem("Kuwait", "KW"));
        ddl.Items.Add(new ListItem("Kyrgyzstan", "KG"));
        ddl.Items.Add(new ListItem("Laos", "LA"));
        ddl.Items.Add(new ListItem("Latvia", "LV"));
        ddl.Items.Add(new ListItem("Lebanon", "LB"));
        ddl.Items.Add(new ListItem("Lesotho", "LS"));
        ddl.Items.Add(new ListItem("Liberia", "LR"));
        ddl.Items.Add(new ListItem("Libya", "LY"));
        ddl.Items.Add(new ListItem("Liechtenstein", "LI"));
        ddl.Items.Add(new ListItem("Lithuania", "LT"));
        ddl.Items.Add(new ListItem("Luxembourg", "LU"));
        ddl.Items.Add(new ListItem("Macau", "MO"));
        ddl.Items.Add(new ListItem("Macedonia", "MK"));
        ddl.Items.Add(new ListItem("Madagascar", "MG"));
        ddl.Items.Add(new ListItem("Malawi", "MW"));
        ddl.Items.Add(new ListItem("Malaysia", "MY"));
        ddl.Items.Add(new ListItem("Maldives", "MV"));
        ddl.Items.Add(new ListItem("Mali", "ML"));
        ddl.Items.Add(new ListItem("Malta", "MT"));
        ddl.Items.Add(new ListItem("Marshall Islands", "MH"));
        ddl.Items.Add(new ListItem("Martinique", "MQ"));
        ddl.Items.Add(new ListItem("Mauritania", "MR"));
        ddl.Items.Add(new ListItem("Mauritius", "MU"));
        ddl.Items.Add(new ListItem("Mayotte", "YT"));
        ddl.Items.Add(new ListItem("Mexico", "MX"));
        ddl.Items.Add(new ListItem("Micronesia", "FM"));
        ddl.Items.Add(new ListItem("Moldova", "MD"));
        ddl.Items.Add(new ListItem("Monaco", "MC"));
        ddl.Items.Add(new ListItem("Mongolia", "MN"));
        ddl.Items.Add(new ListItem("Montserrat", "MS"));
        ddl.Items.Add(new ListItem("Morocco", "MA"));
        ddl.Items.Add(new ListItem("Mozambique", "MZ"));
        ddl.Items.Add(new ListItem("Myanmar", "MM"));
        ddl.Items.Add(new ListItem("Namibia", "NA"));
        ddl.Items.Add(new ListItem("Nauru", "NR"));
        ddl.Items.Add(new ListItem("Nepal", "NP"));
        ddl.Items.Add(new ListItem("Netherlands", "NL"));
        ddl.Items.Add(new ListItem("Netherlands Antilles", "AN"));
        ddl.Items.Add(new ListItem("New Caledonia", "NC"));
        ddl.Items.Add(new ListItem("New Zealand", "NZ"));
        ddl.Items.Add(new ListItem("Nicaragua", "NI"));
        ddl.Items.Add(new ListItem("Niger", "NE"));
        ddl.Items.Add(new ListItem("Nigeria", "NG"));
        ddl.Items.Add(new ListItem("Niue", "NU"));
        ddl.Items.Add(new ListItem("Norfolk Island", "NF"));
        ddl.Items.Add(new ListItem("Northern Mariana Islands", "MP"));
        ddl.Items.Add(new ListItem("Norway", "NO"));
        ddl.Items.Add(new ListItem("Oman", "OM"));
        ddl.Items.Add(new ListItem("Palastin", "PS"));
        ddl.Items.Add(new ListItem("Pakistan", "PK"));
        ddl.Items.Add(new ListItem("Palau", "PW"));
        ddl.Items.Add(new ListItem("Panama", "PA"));
        ddl.Items.Add(new ListItem("Papua New Guinea", "PG"));
        ddl.Items.Add(new ListItem("Paraguay", "PY"));
        ddl.Items.Add(new ListItem("Peru", "PE"));
        ddl.Items.Add(new ListItem("Philippines", "PH"));
        ddl.Items.Add(new ListItem("Pitcairn", "PN"));
        ddl.Items.Add(new ListItem("Poland", "PL"));
        ddl.Items.Add(new ListItem("Portugal", "PT"));
        ddl.Items.Add(new ListItem("Puerto Rico", "PR"));
        ddl.Items.Add(new ListItem("Qatar", "QA"));
        ddl.Items.Add(new ListItem("Reunion", "RE"));
        ddl.Items.Add(new ListItem("Romania", "RO"));
        ddl.Items.Add(new ListItem("Russian Federation", "RU"));
        ddl.Items.Add(new ListItem("Rwanda", "RW"));
        ddl.Items.Add(new ListItem("Saint Kitts and Nevis", "KN"));
        ddl.Items.Add(new ListItem("Saint Lucia", "LC"));
        ddl.Items.Add(new ListItem("Saint Vincent and the Grenadines", "VC"));
        ddl.Items.Add(new ListItem("Samoa", "WS"));
        ddl.Items.Add(new ListItem("San Marino", "SM"));
        ddl.Items.Add(new ListItem("Sao Tome and Principe", "ST"));
        ddl.Items.Add(new ListItem("Saudi Arabia", "SA"));
        ddl.Items.Add(new ListItem("Senegal", "SN"));
        ddl.Items.Add(new ListItem("Seychelles", "SC"));
        ddl.Items.Add(new ListItem("Sierra Leone", "SL"));
        ddl.Items.Add(new ListItem("Singapore", "SG"));
        ddl.Items.Add(new ListItem("Slovak Republic", "SK"));
        ddl.Items.Add(new ListItem("Slovenia", "SI"));
        ddl.Items.Add(new ListItem("Solomon Islands", "SB"));
        ddl.Items.Add(new ListItem("Somalia", "SO"));
        ddl.Items.Add(new ListItem("South Africa", "ZA"));
        ddl.Items.Add(new ListItem("Spain", "ES"));
        ddl.Items.Add(new ListItem("Sri Lanka", "LK"));
        ddl.Items.Add(new ListItem("St. Helena", "SH"));
        ddl.Items.Add(new ListItem("St. Pierre and Miquelon", "PM"));
        ddl.Items.Add(new ListItem("Sudan", "SD"));
        ddl.Items.Add(new ListItem("Suriname", "SR"));
        ddl.Items.Add(new ListItem("Svalbard and Jan Mayen Islands", "SJ"));
        ddl.Items.Add(new ListItem("Swaziland", "SZ"));
        ddl.Items.Add(new ListItem("Sweden", "SE"));
        ddl.Items.Add(new ListItem("Switzerland", "CH"));
        ddl.Items.Add(new ListItem("Syria", "SY"));
        ddl.Items.Add(new ListItem("Taiwan", "TW"));
        ddl.Items.Add(new ListItem("Tajikistan", "TJ"));
        ddl.Items.Add(new ListItem("Tanzania", "TZ"));
        ddl.Items.Add(new ListItem("Thailand", "TH"));
        ddl.Items.Add(new ListItem("Togo", "TG"));
        ddl.Items.Add(new ListItem("Tokelau", "TK"));
        ddl.Items.Add(new ListItem("Tonga", "TO"));
        ddl.Items.Add(new ListItem("Trinidad and Tobago", "TT"));
        ddl.Items.Add(new ListItem("Tunisia", "TN"));
        ddl.Items.Add(new ListItem("Turkey", "TR"));
        ddl.Items.Add(new ListItem("Turkmenistan", "TM"));
        ddl.Items.Add(new ListItem("Turks and Caicos Islands", "TC"));
        ddl.Items.Add(new ListItem("Tuvalu", "TV"));
        ddl.Items.Add(new ListItem("Uganda", "UG"));
        ddl.Items.Add(new ListItem("Ukraine", "UA"));
        ddl.Items.Add(new ListItem("United Arab Emirates", "AE"));
        ddl.Items.Add(new ListItem("United Kingdom", "GB"));
        ddl.Items.Add(new ListItem("Uruguay", "UY"));
        ddl.Items.Add(new ListItem("US Minor Outlying Islands", "UM"));
        ddl.Items.Add(new ListItem("Uzbekistan", "UZ"));
        ddl.Items.Add(new ListItem("Vanuatu", "VU"));
        ddl.Items.Add(new ListItem("Vatican City State (Holy See)", "VA"));
        ddl.Items.Add(new ListItem("Venezuela", "VE"));
        ddl.Items.Add(new ListItem("Viet Nam", "VN"));
        ddl.Items.Add(new ListItem("Virgin Islands (British)", "VG"));
        ddl.Items.Add(new ListItem("Virgin Islands (U.S.)", "VI"));
        ddl.Items.Add(new ListItem("Wallis and Futuna Islands", "WF"));
        ddl.Items.Add(new ListItem("West Bank", "WB"));
        ddl.Items.Add(new ListItem("Western Sahara", "EH"));
        ddl.Items.Add(new ListItem("Yemen", "YE"));
        ddl.Items.Add(new ListItem("Yugoslavia", "YU"));
        ddl.Items.Add(new ListItem("Zaire", "ZR"));
        ddl.Items.Add(new ListItem("Zambia", "ZM"));
        ddl.Items.Add(new ListItem("Zimbabwe", "ZW"));
    }
    public static void CreateStates(DropDownList ddl,string country)
    {
        bool IncludeUS = false;
        bool IncludeCanada = false;
        if(country.Equals("US"))
            IncludeUS = true;
         if(country.Equals("CA"))
            IncludeCanada = true;
        ddl.Items.Clear();
        if (IncludeUS & IncludeCanada)
        {
            ddl.Items.Add(new ListItem("Choose a State/Province", "0"));
        }
        else if (IncludeUS & !IncludeCanada)
        {
            ddl.Items.Add(new ListItem("Choose a State", "0"));
        }
        else if (!IncludeUS & IncludeCanada)
        {
            ddl.Items.Add(new ListItem("Choose a Province", "0"));
        }
        else if (!IncludeUS & !IncludeCanada)
        {
            ddl.Items.Add(new ListItem("Choose a State/Province", "0"));
            ddl.Items.Add(new ListItem("N/A", "1"));
        }
        if (IncludeUS)
        {
            ddl.Items.Add(new ListItem("Alabama", "AL"));
            ddl.Items.Add(new ListItem("Alaska", "AK"));
            ddl.Items.Add(new ListItem("Arizona", "AZ"));
            ddl.Items.Add(new ListItem("Arkansas", "AR"));
            ddl.Items.Add(new ListItem("California", "CA"));
            ddl.Items.Add(new ListItem("California", "CO"));
            ddl.Items.Add(new ListItem("Connecticut", "CT"));
            ddl.Items.Add(new ListItem("D.C.", "DC"));
            ddl.Items.Add(new ListItem("Delaware", "DE"));
            ddl.Items.Add(new ListItem("Florida", "FL"));
            ddl.Items.Add(new ListItem("Georgia", "GA"));
            ddl.Items.Add(new ListItem("Hawaii", "HI"));
            ddl.Items.Add(new ListItem("Idaho", "ID"));
            ddl.Items.Add(new ListItem("Illinois", "IL"));
            ddl.Items.Add(new ListItem("Indiana", "IN"));
            ddl.Items.Add(new ListItem("Iowa", "IA"));
            ddl.Items.Add(new ListItem("Kansas", "KS"));
            ddl.Items.Add(new ListItem("Kentucky", "KY"));
            ddl.Items.Add(new ListItem("Louisiana", "LA"));
            ddl.Items.Add(new ListItem("Maine", "ME"));
            ddl.Items.Add(new ListItem("Maryland", "MD"));
            ddl.Items.Add(new ListItem("Massachusetts", "MA"));
            ddl.Items.Add(new ListItem("Michigan", "MI"));
            ddl.Items.Add(new ListItem("Minnesota", "MN"));
            ddl.Items.Add(new ListItem("Mississippi", "MS"));
            ddl.Items.Add(new ListItem("Missouri", "MO"));
            ddl.Items.Add(new ListItem("Montana", "MT"));
            ddl.Items.Add(new ListItem("Nebraska", "NE"));
            ddl.Items.Add(new ListItem("Nevada", "NV"));
            ddl.Items.Add(new ListItem("New Hampshire", "NH"));
            ddl.Items.Add(new ListItem("New Jersey", "NJ"));
            ddl.Items.Add(new ListItem("New Mexico", "NM"));
            ddl.Items.Add(new ListItem("New York", "NY"));
            ddl.Items.Add(new ListItem("North Carolina", "NC"));
            ddl.Items.Add(new ListItem("North Dakota", "ND"));
            ddl.Items.Add(new ListItem("Ohio", "OH"));
            ddl.Items.Add(new ListItem("Oklahoma", "OK"));
            ddl.Items.Add(new ListItem("Oregon", "OR"));
            ddl.Items.Add(new ListItem("Pennsylvania", "PA"));
            ddl.Items.Add(new ListItem("Rhode Island", "RI"));
            ddl.Items.Add(new ListItem("South Carolina", "SC"));
            ddl.Items.Add(new ListItem("South Dakota", "SD"));
            ddl.Items.Add(new ListItem("Tennessee", "TN"));
            ddl.Items.Add(new ListItem("Texas", "TX"));
            ddl.Items.Add(new ListItem("Utah", "UT"));
            ddl.Items.Add(new ListItem("Vermont", "VT"));
            ddl.Items.Add(new ListItem("Virginia", "VA"));
            ddl.Items.Add(new ListItem("Washington", "WA"));
            ddl.Items.Add(new ListItem("West Virginia", "WV"));
            ddl.Items.Add(new ListItem("Wisconsin", "WI"));
            ddl.Items.Add(new ListItem("Wyoming", "WY"));
        }
        if (IncludeCanada)
        {
            ddl.Items.Add(new ListItem("British Columbia", "BC"));
            ddl.Items.Add(new ListItem("Manitoba", "MB"));
            ddl.Items.Add(new ListItem("New Brunswick", "NB"));
            ddl.Items.Add(new ListItem("Newfoundland and Labrador", "NL"));
            ddl.Items.Add(new ListItem("Northwest Territories", "NT"));
            ddl.Items.Add(new ListItem("Nova Scotia", "NS"));
            ddl.Items.Add(new ListItem("Nunavut", "NU"));
            ddl.Items.Add(new ListItem("Ontario", "ON"));
            ddl.Items.Add(new ListItem("Prince Edward Island", "PE"));
            ddl.Items.Add(new ListItem("Quebec", "QC"));
            ddl.Items.Add(new ListItem("Saskatchewan", "SK"));
            ddl.Items.Add(new ListItem("Yukon Territories", "YT"));
        }
    }
    public BCMOnlineDS.OrdersRow ShopingCart()
    {
        if (HttpContext.Current.Session["ShopingCart"] != null)
            return (BCMOnlineDS.OrdersRow)HttpContext.Current.Session["ShopingCart"];
        return null;
    }
    public BCMOnlineDS.OrderItemsDataTable ShopingCartItems()
    {
        BCMOnlineDSTableAdapters.OrderItemsTableAdapter orderItems = new BCMOnlineDSTableAdapters.OrderItemsTableAdapter();
        if(ShopingCart() != null)
        return orderItems.GetDataByOrderID(ShopingCart().OrderID);
        return null;
        //if (HttpContext.Current.Session["ShopingCartItems"] != null)
        //    return (BCMOnlineDS.OrderItemsDataTable)HttpContext.Current.Session["ShopingCartItems"];
       
    }
    public static void CreateShoppingCart()
    {
        BCMOnlineDSTableAdapters.OrdersTableAdapter orderta = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
        BCMOnlineDS ds = new BCMOnlineDS();
        BCMOnlineDS.OrdersRow dr = ds.Orders.NewOrdersRow();
        dr.Active = true;
        dr.AddedBy = HttpContext.Current.User.Identity.Name;
        dr.AddedDate = DateTime.Now;
        dr.CustomerEmail = HttpContext.Current.User.Identity.Name;
        dr.CustomerPhone = "";
        dr.Shipping = 0;
        dr.ShippingCity = "";
        dr.ShippingCountry = "";
        dr.ShippingFirstName = "";
        dr.ShippingLastName = "";
        dr.ShippingPostalCode = "";
        dr.ShippingState = "";
        dr.ShippingStreet = "";
        dr.StatusID = 1;
        dr.SubTotal = 0;
        dr.UpdatedDate = DateTime.Now;
        ds.Orders.Rows.Add(dr);
        orderta.Update(dr);
        HttpContext.Current.Session["ShopingCart"] = dr;
        //int orderId = orderta.Insert(DateTime.Now, HttpContext.Current.User.Identity.Name, 1, 0, 0, "", "", "", "", "", "", "", HttpContext.Current.User.Identity.Name, "", "", DateTime.Now, "", "", DateTime.Now, HttpContext.Current.User.Identity.Name, true);
    }
    public void UpdateShoppingCartItemQuantity(int id, int quantity)
    {
        BCMOnlineDSTableAdapters.OrderItemsTableAdapter orderItems = new BCMOnlineDSTableAdapters.OrderItemsTableAdapter();
        BCMOnlineDS.OrderItemsRow dr = (BCMOnlineDS.OrderItemsRow)orderItems.GetDataByOrderItemID(id).Rows[0];
        dr.Quantity = quantity;
        dr.UpdatedBy = HttpContext.Current.User.Identity.Name;
        dr.UpdatedDate = DateTime.Now;
        orderItems.Update(dr);
        
     }
    public void UpdateShoppingCartTotal()
    {
        BCMOnlineDSTableAdapters.OrdersTableAdapter orderta = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
        decimal total = 0;
        BCMOnlineDS.OrdersRow dr = ShopingCart();
        if (ShopingCartItems() != null)
        {
            foreach (BCMOnlineDS.OrderItemsRow drItems in ShopingCartItems())
            {
                total += (drItems.Quantity * drItems.UnitPrice);
            }
            dr.SubTotal = total;
            dr.UpdatedBy = HttpContext.Current.User.Identity.Name;
            dr.UpdatedDate = DateTime.Now;
            orderta.Update(dr);
            HttpContext.Current.Session["ShopingCart"] = dr;
        }
    }
    public void UpdateOrder(string shippingMethod, decimal shipping,
                                 string shippingFirstName, string shippingLastName, string shippingStreet,
                                 string shippingPostalCode, string shippingCity, string shippingState,
                                 string shippingCountry, string customerEmail, string customerPhone,
                                string customerFax, string transactionID)
    {
        BCMOnlineDSTableAdapters.OrdersTableAdapter orderTa = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
        BCMOnlineDS.OrdersRow dr = ShopingCart();
        dr.AddedBy = HttpContext.Current.User.Identity.Name;
        dr.CustomerEmail = HttpContext.Current.User.Identity.Name;
        dr.CustomerPhone = customerPhone;
        dr.Shipping = shipping;
        dr.ShippingCity = shippingCity;
        dr.ShippingCountry = shippingCountry;
        dr.ShippingFirstName = shippingFirstName;
        dr.ShippingLastName = shippingLastName;
        dr.ShippingPostalCode = shippingPostalCode;
        dr.ShippingState = shippingState;
        dr.ShippingStreet = shippingStreet;
        dr.StatusID = 1;
        dr.UpdatedDate = DateTime.Now;
        dr.UpdatedBy = HttpContext.Current.User.Identity.Name;
        orderTa.Update(dr);
        HttpContext.Current.Session["ShopingCart"] = dr;
    }

    public string GetPayPalPaymentUrl(params int[] orderId)
    {
        BCMOnlineDSTableAdapters.OrdersTableAdapter orderta = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
        BCMOnlineDS.OrdersRow dr = ShopingCart();
        if (orderId.Length > 0)
            dr = (BCMOnlineDS.OrdersRow)orderta.GetDataByOrderID(orderId[0]).Rows[0];
        string serverUrl;
        bool SandboxMode = true;
         if (SandboxMode)
        {
            serverUrl = "https://www.sandbox.paypal.com/us/cgi-bin/webscr";
        }
        else
        {
            serverUrl = "https://www.paypal.com/us/cgi-bin/webscr";
        }
        
        string amount = dr.SubTotal.ToString("N2").Replace(",", ".");
        string shipping = dr.Shipping.ToString("N2").Replace(",", ".");
        string firstname = HttpUtility.UrlEncode(dr.ShippingFirstName);
        string lastname = HttpUtility.UrlEncode(dr.ShippingLastName);
        string address = HttpUtility.UrlEncode(dr.ShippingStreet);
        string city = HttpUtility.UrlEncode(dr.ShippingCity);
        string state = HttpUtility.UrlEncode(dr.ShippingState);
        string zip = HttpUtility.UrlEncode(dr.ShippingPostalCode);
        string baseUrl =
            HttpContext.Current.Request.Url.AbsoluteUri.Replace(HttpContext.Current.Request.Url.PathAndQuery, "") +
            HttpContext.Current.Request.ApplicationPath;
        if (!baseUrl.EndsWith("/"))
        {
            baseUrl = baseUrl + "/";
        }
        string notifyUrl = HttpUtility.UrlEncode(baseUrl + "PayPal/PayPalIPN.ashx");
        string returnUrl = HttpUtility.UrlEncode(baseUrl + "PayPal/OrderCompleted.aspx?OrderID=" + dr.OrderID);
        string cancelUrl = HttpUtility.UrlEncode(baseUrl + "PayPal/OrderCancelled.aspx?OrderID=" + dr.OrderID);
        string business = HttpUtility.UrlEncode("pharma_1307010033_biz@live.com");
        string itemName = HttpUtility.UrlEncode("Order #" + dr.OrderID);
        var url = new StringBuilder();
        url.AppendFormat(
            "{0}?cmd=_xclick&upload=1&rm=2&no_shipping=1&no_note=1&currency_code={1}&business={2}&item_number={3}&custom={3}&item_name={4}&amount={5}&shipping={6}&notify_url={7}&return={8}&cancel_return={9}&first_name={10}&last_name={11}&address1={12}&city={13}&state={14}&zip={15}",
            new object[]
                    {
                        serverUrl, "USD", business, dr.OrderID, itemName, amount,
                        shipping, notifyUrl, returnUrl, cancelUrl, firstname, lastname, address, city, state, zip
                    });
        return url.ToString();
    }
    public static string getStatusTitle(int id)
    {
        BCMOnlineDSTableAdapters.OrderStatusTableAdapter statusTa = new BCMOnlineDSTableAdapters.OrderStatusTableAdapter();
        BCMOnlineDS.OrderStatusRow dr = (BCMOnlineDS.OrderStatusRow)statusTa.GetDataByStatusId(id).Rows[0];
        return dr.Title;
    }
}
