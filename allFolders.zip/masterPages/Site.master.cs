﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Page_Init(object sender, EventArgs e)
    {
        this.Page.ViewStateUserKey = Session.SessionID; 
    }
    public string  resolveMasterPageUrl
    {
        get { string url = this.ResolveUrl("~") + "masterPages";
        return url;
        }
       
    }
    public UpdatePanel GetUpdatePanel()
    {
        return this.UpdatePanel1;
    }
    public ScriptManager GetScriptManager()
    {
        return this.ScriptManager1;
    }
    //protected void ScriptManager1_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
    //{
    //    Context.ClearError();
    //}
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["SToken"] = "%" + txtSearch.Text + "%";
        Response.Redirect(@"~\Services\ProductsList.aspx");
    }
}
