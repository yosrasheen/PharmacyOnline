﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Services_ShoppingCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Helper.CreateCountries(ddlCountries);
            Helper.CreateStates(ddlState, ddlCountries.SelectedValue);
            BindShoppingCart();
            UpdateTotals();
        }
        else
        {
            bool isAuthenticated = this.User.Identity.IsAuthenticated;
            if (isAuthenticated)
            {
                mvwShipping.ActiveViewIndex = 1;
            }
            else
            {
                mvwShipping.ActiveViewIndex = 0;
                wizSubmitOrder.StartNextButtonText = string.Empty;
            }

        }
    }
    protected void Page_Init(object sender, System.EventArgs e)
    {

        ScriptManager sm = ScriptManager.GetCurrent(this);

        if ((sm != null))
        {

            sm.EnableHistory = true;
            sm.Navigate += ScriptManagerNavigate;

        }
    }
    protected void ScriptManagerNavigate(object sender, HistoryEventArgs e)
    {

        string indexString = e.State["ShoppingCart"];

        if (string.IsNullOrEmpty(indexString))
        {
            wizSubmitOrder.ActiveStepIndex = 0;
        }
        else
        {
            int index = int.Parse(indexString);
            wizSubmitOrder.ActiveStepIndex = index;

        }
    }
    protected void BindShoppingCart()
    {
        Helper hlp = new Helper();
        if (hlp.ShopingCart() != null)
        {
            if (hlp.ShopingCart().StatusID > 1)
                HttpContext.Current.Session["ShopingCart"] = null;
        }
        lvOrderItems.DataSource = hlp.ShopingCartItems();
        lvOrderItems.DataBind();
    }
    protected void UpdateTotals()
    {
        Helper hlp = new Helper();
        foreach (ListViewDataItem lvdi in lvOrderItems.Items)
        {
           // if ((System.Data.DataRowView)lvdi.DataItem != null)
            //{
                //BCMOnlineDS.OrderItemsRow lCartItem = (BCMOnlineDS.OrderItemsRow)((System.Data.DataRowView)lvdi.DataItem).Row;
                //int id = lCartItem.OrderItemID;
            int id = int.Parse(lvOrderItems.DataKeys[lvdi.DataItemIndex][0].ToString());
                int quantity = int.Parse(((TextBox)lvdi.FindControl("txtQuantity")).Text);
                hlp.UpdateShoppingCartItemQuantity(id, quantity);
            //}
        }
        

        // if the shopping cart is empty, hide the link to proceed
        if (lvOrderItems.Items.Count == 0)
        {
            wizSubmitOrder.StartNextButtonText = string.Empty;
            panTotals.Visible = false;
        }
        else
        {
            hlp.UpdateShoppingCartTotal();
            // display the subtotal and the total amounts
            lblSubtotal.Text = Helper.FormatPrice(hlp.ShopingCart().SubTotal);
            lblTotal.Text = Helper.FormatPrice(hlp.ShopingCart().SubTotal + (5 - ddlShippingMethods.SelectedIndex) * (decimal)0.75);
            wizSubmitOrder.StartNextButtonText = "Proceed with order";
        }
        BindShoppingCart();
    }
    protected void lvOrderItems_ItemDeleting(object sender, System.Web.UI.WebControls.ListViewDeleteEventArgs e)
    {

        int lProductId = int.Parse(lvOrderItems.DataKeys[e.ItemIndex][0].ToString());
        BCMOnlineDSTableAdapters.OrderItemsTableAdapter orderItemTa = new BCMOnlineDSTableAdapters.OrderItemsTableAdapter();
        orderItemTa.Delete(lProductId);
        BindShoppingCart();
        UpdateTotals();
    }

    
    protected void wizSubmitOrder_ActiveStepChanged(object sender, System.EventArgs e)
    {

        ScriptManager sm = ScriptManager.GetCurrent(this);

        if ((sm != null))
        {
            if (sm.IsInAsyncPostBack & !sm.IsNavigating)
            {
                sm.AddHistoryPoint("ShoppingCart", wizSubmitOrder.ActiveStepIndex.ToString(),
                    "Shopping Cart Step " + wizSubmitOrder.ActiveStepIndex);
            }
        }
        
        if (wizSubmitOrder.ActiveStepIndex == 1)
        {
            UpdateTotals();

            if (this.User.Identity.IsAuthenticated)
            {
                BCMOnlineDSTableAdapters.OrdersTableAdapter orderTa = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
                BCMOnlineDS.OrdersRow dr = null;
                try
                {
                    dr = (BCMOnlineDS.OrdersRow)orderTa.GetDataByCustomerLastOrder(User.Identity.Name).Rows[0];
                }
                catch { }
                if (dr != null)
                {
                    if (txtFirstName.Text.Trim().Length == 0) txtFirstName.Text = dr.ShippingFirstName;
                    if (txtLastName.Text.Trim().Length == 0) txtLastName.Text = dr.ShippingLastName;
                    if (txtEmail.Text.Trim().Length == 0) txtEmail.Text = User.Identity.Name;
                    if (txtStreet.Text.Trim().Length == 0) txtStreet.Text = dr.ShippingStreet;
                    if (txtPostalCode.Text.Trim().Length == 0) txtPostalCode.Text = dr.ShippingPostalCode;
                    if (txtCity.Text.Trim().Length == 0) txtCity.Text = dr.ShippingCity;

                    if (ddlCountries.SelectedIndex == 0 && !string.IsNullOrEmpty(dr.ShippingCountry))
                    {
                        ddlCountries.SelectedValue = dr.ShippingCountry;
                        ddlCountries_SelectedIndexChanged(this, e);
                    }

                    if (ddlState.SelectedIndex == 0 && !string.IsNullOrEmpty(dr.ShippingState)) ddlState.SelectedValue = dr.ShippingState;
                    
                    if (txtPhone.Text.Trim().Length == 0) txtPhone.Text =dr.CustomerPhone;
                    if (txtFax.Text.Trim().Length == 0) txtFax.Text = dr.IsCustomerFaxNull()? "" : dr.CustomerFax;
                }

            }
        }
        else if (wizSubmitOrder.ActiveStepIndex == 2)
        {
            lblReviewFirstName.Text = txtFirstName.Text;
            lblReviewLastName.Text = txtLastName.Text;
            lblReviewStreet.Text = txtStreet.Text;
            lblReviewCity.Text = txtCity.Text;
            lblReviewState.Text = ddlState.SelectedValue;
            lblReviewPostalCode.Text = txtPostalCode.Text;
            lblReviewCountry.Text = ddlCountries.SelectedValue;
            Helper hlp = new Helper();
            lblReviewSubtotal.Text = Helper.FormatPrice(hlp.ShopingCart().SubTotal);
            lblReviewShippingMethod.Text = ddlShippingMethods.SelectedItem.Text;
            lblReviewTotal.Text = Helper.FormatPrice(hlp.ShopingCart().SubTotal + ((5 - ddlShippingMethods.SelectedIndex) * (decimal)0.75));

            repOrderItems.DataSource = hlp.ShopingCartItems();
            repOrderItems.DataBind();

        }
    }

    protected void wizSubmitOrder_FinishButtonClick(object sender, System.Web.UI.WebControls.WizardNavigationEventArgs e)
    {

        // check that the user is still logged in (the cookie may have expired)
        // and if not redirect to the login page
         Helper hlp = new Helper();
        if (this.User.Identity.IsAuthenticated)
        {

            //We can reasonably assume if a customer is going to pay for the order via PayPal, 
            //the order can only be migrated from the cart to the Order tables once. 
            //Otherwise interaction with PayPal becomes a lot more tricky.
            string shippingMethod = ddlShippingMethods.SelectedItem.Text;
            //shippingMethod = shippingMethod.Substring(0, shippingMethod.LastIndexOf("(")).Trim();

              // saves the order into the DB, and clear the shopping cart in the profile

            hlp.UpdateOrder(shippingMethod, ((5 - ddlShippingMethods.SelectedIndex) * (decimal)0.75), txtFirstName.Text, txtLastName.Text, txtStreet.Text, txtPostalCode.Text, txtCity.Text, ddlState.SelectedValue, ddlCountries.SelectedValue,
                txtEmail.Text, txtPhone.Text, txtFax.Text, "");
            
             // redirect to PayPal for the credit-card payment

            this.Response.Redirect(hlp.GetPayPalPaymentUrl(), false);
        }
        else
        {
            this.RequestLogin();
        }
    }

    private void RequestLogin()
    {
        Response.Redirect(FormsAuthentication.LoginUrl + "?ReturnUrl=" + Request.Url.PathAndQuery);
    }

    protected void wizSubmitOrder_NextButtonClick(object sender, System.Web.UI.WebControls.WizardNavigationEventArgs e)
    {

        //Make sure a shipping method has been selected.
        if (wizSubmitOrder.ActiveStepIndex == 0)
        {
            Page.Validate("ShippingMethod");
            if (!Page.IsValid)
            {
                e.Cancel = true;
            }
           // int ShippingMethodId = int.Parse(ddlShippingMethods.SelectedValue);

        }
        if (wizSubmitOrder.ActiveStepIndex == 1)
        {
            Page.Validate("ShippingAddress");
            if (!Page.IsValid)
            {
                e.Cancel = true;
            }
            
        }
    }

    protected void ddlShippingMethods_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        UpdateTotals();
    }

    protected void QtyChanged(object sender, System.EventArgs e)
    {
        UpdateTotals();
    }
    protected void ddlCountries_SelectedIndexChanged(object sender, EventArgs e)
    {
        Helper.CreateStates(ddlState, ddlCountries.SelectedValue);
    }
}