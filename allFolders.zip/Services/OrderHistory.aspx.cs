﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Services_OrderHistory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["UserName"] = User.Identity.Name;
    }
    protected void lvOrders_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        ListViewDataItem lvdi = (ListViewDataItem)e.Item;

        if (lvdi.ItemType == ListViewItemType.DataItem)
        {
            try
            {
                Repeater repOrderItems = (Repeater)lvdi.FindControl("repOrderItems");
                int id = int.Parse(lvOrders.DataKeys[lvdi.DataItemIndex][0].ToString());
                BCMOnlineDSTableAdapters.OrderItemsTableAdapter orderItemsTa = new BCMOnlineDSTableAdapters.OrderItemsTableAdapter();
                repOrderItems.DataSource = orderItemsTa.GetDataByOrderID(id);
                repOrderItems.DataBind();
            }
            catch { }
        }
    }
    protected void lvOrders_PagePropertiesChanged(object sender, EventArgs e)
    {

    }
}