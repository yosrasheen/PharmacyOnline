﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Services_ShowProduct : System.Web.UI.Page
{
    protected bool UserCanEdit
    {
        get { return (User.Identity.IsAuthenticated && (User.IsInRole("Administrator"))); }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        int productId;
        if (! int.TryParse(Request.QueryString["id"].ToString(),out productId))
        {
            throw new ApplicationException("Missing parameter on the querystring.");
        }
        if (!IsPostBack)
        {
            // try to load the product with the specified ID, and raise an exception if it doesn't exist
            BindProduct();
        }
    }
    protected void btnDelete_Click(object sender, ImageClickEventArgs e)
    {
        using (BCMOnlineDSTableAdapters.MedicineTableAdapter lProductrpt = new BCMOnlineDSTableAdapters.MedicineTableAdapter())
        {
            int ProductId;
            int.TryParse(Request.QueryString["id"].ToString(), out ProductId);
            lProductrpt.Delete(ProductId);
            Response.Redirect("BrowseProducts.aspx", false);
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        using (BCMOnlineDSTableAdapters.MedicineTableAdapter lProductrpt = new BCMOnlineDSTableAdapters.MedicineTableAdapter())
        {
            int ProductId;
            int.TryParse(Request.QueryString["id"].ToString(), out ProductId);
            BCMOnlineDS.MedicineRow lproduct = (BCMOnlineDS.MedicineRow)lProductrpt.GetDataByMedicineID(ProductId).Rows[0];
            Helper hlp = new Helper();
            if (hlp.ShopingCart() == null)
            {
                Helper.CreateShoppingCart();
            }
            BCMOnlineDSTableAdapters.OrderItemsTableAdapter ordItem = new BCMOnlineDSTableAdapters.OrderItemsTableAdapter();
            ordItem.Insert(DateTime.Now, User.Identity.Name, hlp.ShopingCart().OrderID, ProductId, lproduct.Title, lproduct.FinalUnitPrice, 1, DateTime.Now, User.Identity.Name, true);
            //lShoppingCart.InsertItem(lProduct.ID, lProduct.Title,lProduct.FinalUnitPrice);
            //Profile.ShoppingCart = lShoppingCart;
            Response.Redirect("ShoppingCart.aspx", false);
        }
    }
    protected void BindProduct()
    {
        using (BCMOnlineDSTableAdapters.MedicineTableAdapter lProductrpt = new BCMOnlineDSTableAdapters.MedicineTableAdapter())
        {
            int ProductId;
            int.TryParse(Request.QueryString["id"].ToString(), out ProductId);
            BCMOnlineDS.MedicineRow lproduct = (BCMOnlineDS.MedicineRow)lProductrpt.GetDataByMedicineID(ProductId).Rows[0];
            if ((lproduct == null)) throw new ApplicationException("No product was found for the specified ID.");

            // display all article's data on the page
            lblTitle.Text = lproduct.Title;
            Title = lproduct.Title;
            lblDescription.Text = lproduct.Description;

            if(!lproduct.IsDrug_ClassNull())
            lblClass.Text = lproduct.Drug_Class.ToString();
            if (!lproduct.IsDrug_HowToUseNull())
            lblHowToUse.Text = lproduct.Drug_HowToUse.ToString();
            if (!lproduct.IsDrug_StorageNull())
            lblStorage.Text = lproduct.Drug_Storage.ToString();
            if (!lproduct.IsDrug_SyptomsNull())
            lblSyptoms.Text = lproduct.Drug_Syptoms.ToString();
            if (!lproduct.IsDrug_UsesNull())
            lblUses.Text = lproduct.Drug_Uses.ToString();
            panEditProduct.Visible = UserCanEdit;   
            lnkEditProduct.NavigateUrl = string.Format(lnkEditProduct.NavigateUrl, ProductId);
            lblPrice.Text = Helper.FormatPrice(lproduct.FinalUnitPrice);
            lblDiscountedPrice.Text = string.Format(lblDiscountedPrice.Text,Helper.FormatPrice(lproduct.UnitPrice),
                                                    lproduct.DiscountPercentage);
            lblDiscountedPrice.Visible = (lproduct.DiscountPercentage > 0);
            if (lproduct.SmallImageUrl.Length > 0) imgProduct.Src = lproduct.SmallImageUrl;
            imgProduct.Alt = lproduct.Title;
            if (lproduct.SmallImageUrl.Length > 0)
            {
                lnkFullImage.NavigateUrl = lproduct.SmallImageUrl;
                lnkFullImage.Visible = true;
            }
            else
            {
                lnkFullImage.Visible = false;
            }
        }
    }
}