﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Services_ProductsList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public bool IsAdmin { get { return User.IsInRole("Administrator"); } }
    protected void lvProducts_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        ListViewDataItem lvdi = (ListViewDataItem)e.Item;

        if ((lvdi != null))
        {

            BCMOnlineDS.MedicineRow lProduct = (BCMOnlineDS.MedicineRow)((System.Data.DataRowView)lvdi.DataItem).Row;

            if ((lProduct != null))
            {

                Panel Panel1 = (Panel)lvdi.FindControl("Panel1");
                Panel1.Visible = lProduct.DiscountPercentage > 0 ? true : false;

                Literal ltlDiscountPercentage = (Literal)lvdi.FindControl("ltlDiscountPercentage");
                ltlDiscountPercentage.Text = string.Format("{0}% Off", lProduct.DiscountPercentage);

                Literal ltlUnitPrice = (Literal)lvdi.FindControl("ltlUnitPrice");

                ltlUnitPrice.Text = string.Format("<strike>{0}</strike>", Helper.FormatPrice(lProduct.UnitPrice));

            }

        }
    }
}