﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class Account_Register : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterUser.ContinueDestinationPageUrl = Request.QueryString["ReturnUrl"];
    }

    protected void RegisterUser_CreatedUser(object sender, EventArgs e)
    {
        FormsAuthentication.SetAuthCookie(RegisterUser.UserName, false /* createPersistentCookie */);
        MembershipUser mu = Membership.GetUser(RegisterUser.UserName);
        mu.Email = RegisterUser.UserName;
        Membership.UpdateUser(mu);
        string continueUrl = RegisterUser.ContinueDestinationPageUrl;
        if (String.IsNullOrEmpty(continueUrl))
        {
            continueUrl = "~/";
        }
        try
        {
            //smtp.Host = ConfigurationManager.AppSettings["SMTP"];
            //System.Net.NetworkCredential cred = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTPUser"],
            //ConfigurationManager.AppSettings["SMTPPassword"]);
            //smtp.UseDefaultCredentials = false;
            //smtp.Credentials = cred;
            System.Net.Mail.SmtpClient sC = new System.Net.Mail.SmtpClient();
            //sC.SendCompleted += new System.Net.Mail.SendCompletedEventHandler(sC_SendCompleted);
            sC.Send("postmaster@onlinepharmacy.com", RegisterUser.UserName, "onlinepharmacy.com - Thank you for registering", "Thank you for registering to Our website! Following are the credentials you selected for logging in:\n Email: " + RegisterUser.UserName + "\n Password: " + mu.GetPassword() + "\n See you online! \n - Site Team");
            Response.Redirect(continueUrl, false);
            
            
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
        
    }

    //void sC_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
    //{
    //    Response.Write(e.Error);
        
    //}
   

}
