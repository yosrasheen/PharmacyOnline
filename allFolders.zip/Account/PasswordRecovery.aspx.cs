﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Account_PasswordRecovery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    ////protected void PasswordRecovery1_SendingMail(object sender, MailMessageEventArgs e)
    ////{
    ////    Response.Write(e.Message);
    ////}
    ////protected void PasswordRecovery1_SendMailError(object sender, SendMailErrorEventArgs e)
    ////{
    ////    Response.Write(e.Exception.ToString());
    ////}
}