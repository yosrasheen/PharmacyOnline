﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PayPal_OrderCompleted : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            BCMOnlineDSTableAdapters.OrdersTableAdapter orderTa = new BCMOnlineDSTableAdapters.OrdersTableAdapter();
            BCMOnlineDS.OrdersRow order = (BCMOnlineDS.OrdersRow)orderTa.GetDataByOrderID(Convert.ToInt32(this.Request.QueryString["OrderID"].ToString())).Rows[0];
            if (order.StatusID == 1 || order.StatusID == 4) // waiting for payment
            {
                order.StatusID = 2;  // Confirmed
                orderTa.Update(order);
                HttpContext.Current.Session["ShopingCart"] = null;                
            }
        }
        catch { }


    }
}